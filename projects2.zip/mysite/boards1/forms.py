from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content', 'image']
        widgets = {
            'image': forms.ClearableFileInput(attrs={'onchange': 'validateFile()'}),
        }

    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image:
            extension = image.name.rsplit('.', 1)[1].lower()
            if extension not in ['jpg', 'jpeg', 'png']:
                raise forms.ValidationError("JPG, JPEG, PNG 파일만 업로드 가능합니다.")
        return image