from django.shortcuts import render, redirect
from .forms import PostForm
from .models import Post, Comment
from django.contrib.auth import authenticate, login
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.contrib.auth.forms import UserCreationForm

def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('post_list')
    else:
        form = PostForm()
    return render(request, 'boards1/post_form.html', {'form': form})

def post_list(request):
    posts = Post.objects.all()  # 모든 게시글을 가져옵니다.
    return render(request, 'boards1/post_list.html', {'posts': posts})

@login_required
def add_comment_to_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        text = request.POST.get('comment')
        comment = Comment.objects.create(post=post, author=request.user, text=text)
        # 여기서 리다이렉트 될 상세 페이지 URL을 설정하세요.
        return redirect('post_detail', pk=post.pk)
    
def like_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if post.likes.filter(id=request.user.id).exists():
        post.likes.remove(request.user)
    else:
        post.likes.add(request.user)
    return redirect('boards1:post_detail', pk=pk)

def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)  # 아직 저장하지 않습니다.
            post.created_at = timezone.now()  # created_at 필드에 현재 시간 할당
            post.save()  # 이제 저장합니다.
            return redirect('boards1:post_detail', pk=post.pk)
    else:
        form = PostForm()
    return render(request, 'boards1/post_form.html', {'form': form})

def post_delete(request, pk):
    post = get_object_or_404(Post, pk=pk)
    post.delete()
    return redirect('boards1:post_list')

def post_edit(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            form.save()
            return redirect('boards1:post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'boards1/post_edit.html', {'form': form})

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    # 비회원이 댓글을 남기려고 하면 로그인 페이지로 리다이렉트하는 로직을 포함할 수 있습니다.
    return render(request, 'boards1/post_detail.html', {'post': post})

def login_view(request):
    # 로그인 로직
    return render(request, 'login.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('post_create')  # 회원가입 후 리디렉트할 페이지
    else:
        form = UserCreationForm()
    return render(request, 'boards1/signup.html', {'form': form})