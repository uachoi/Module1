from . import views
from django.urls import path

app_name = 'boards1'  # 네임스페이스 설정

urlpatterns = [
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('post/create/', views.post_create, name='post_create'),
    path('', views.post_list, name='post_list'),
    path('post/<int:pk>/comment/', views.add_comment_to_post, name='add_comment'),
    path('post/<int:pk>/like/', views.like_post, name='like_post'),
    path('<int:pk>/delete/', views.post_delete, name='post_delete'),
    path('<int:pk>/edit/', views.post_edit, name='post_edit'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup, name='signup'),
]
