from django.apps import AppConfig


class Boards1Config(AppConfig):
    name = 'boards1'
