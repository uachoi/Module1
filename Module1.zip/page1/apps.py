from django.apps import AppConfig


class page1Config(AppConfig):
    name = 'page1'